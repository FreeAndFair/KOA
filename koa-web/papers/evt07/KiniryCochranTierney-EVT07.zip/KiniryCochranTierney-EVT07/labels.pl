# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/cite_Meyer92b/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:JMLModerateExample/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:conclusions/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BurdyEtal05-STTT/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Cochran06/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WaldenNerson95/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_CEV02/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kiniry04-R0420/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Leavens-etal03b/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_CEV00/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LeavensBakerRuby-Prelim/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ChalinEtal06/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Cheon-Leavens02/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kiniry02-PhDThesis/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KiniryCok04/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KiniryEtAl06/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LeavensBakerRuby99/;
$external_labels{$key} = "$URL/" . q|paper.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/fig:JMLModerateExample/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:conclusions/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

1;

