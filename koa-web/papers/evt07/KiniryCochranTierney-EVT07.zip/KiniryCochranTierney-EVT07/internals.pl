# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/cite_Meyer92b/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:JMLModerateExample/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:conclusions/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BurdyEtal05-STTT/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Cochran06/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_WaldenNerson95/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_CEV02/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kiniry04-R0420/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Leavens-etal03b/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_CEV00/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LeavensBakerRuby-Prelim/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ChalinEtal06/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Cheon-Leavens02/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Kiniry02-PhDThesis/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KiniryCok04/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KiniryEtAl06/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LeavensBakerRuby99/;
$ref_files{$key} = "$dir".q|paper.html|; 
$noresave{$key} = "$nosave";

1;

