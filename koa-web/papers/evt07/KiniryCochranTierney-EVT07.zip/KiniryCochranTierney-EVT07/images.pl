# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/{figure*}{{footnotesize{preform{<verbatim_mark>verbatim549#preform{}{{{figure*};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="677" HEIGHT="602" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\begin{figure*}{\footnotesize
\begin{verbatim}/**
* Distribute the surplus...
...ll @*/ ie.koa.Candidate candidateWithSurplus);\end{verbatim}
}
\end{figure*}">|; 

$key = q/1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$1$">|; 

$key = q/0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$0$">|; 

1;

